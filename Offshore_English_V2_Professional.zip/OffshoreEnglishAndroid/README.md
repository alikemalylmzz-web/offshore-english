# Offshore English Professional v2.1

Professional Android UI + downloadable lesson system.

## Highlights
- New native-style dashboard
- Bottom navigation (Home / Lessons / Updates)
- Continue-learning shortcut
- Lesson search
- Professional offshore color system and icon
- Polished lesson cards/buttons/progress screens
- Android 12+ splash screen
- Downloadable future lessons via `lessons/manifest.json`
- Version code 3 / version name 2.1

Package: `com.offshoreenglish.trainer`

## Stable sideload updates
Debug APKs are signed with the bundled development keystore so future GitHub builds can install over Professional v2.1 without uninstalling. This development key is not intended for Google Play release signing.
