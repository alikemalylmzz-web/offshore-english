OFFSHORE ENGLISH - YENİ DERS SİSTEMİ

Uygulama şu adresi kontrol eder:
https://raw.githubusercontent.com/alikemalylmzz-web/offshore-english/main/lessons/manifest.json

GitHub deposunda bir kez "lessons" klasörü ve manifest.json oluşturulmalıdır.

Yeni bir ders örneği:

{
  "version": 2,
  "lessons": [
    {
      "id": "5",
      "title": "Bölüm 5 - Phrasal Verbs",
      "description": "Günlük ve offshore phrasal verbs",
      "revision": 1,
      "url": "https://raw.githubusercontent.com/alikemalylmzz-web/offshore-english/main/lessons/bolum5.html"
    }
  ]
}

Uygulamadaki "Yeni dersleri kontrol et" düğmesi manifest dosyasını okur,
ders HTML dosyalarını telefona indirir ve sonraki açılışlarda çevrimdışı da açabilir.

Not:
ChatGPT'nin GitHub bağlantısı şu anda depoyu okuyabiliyor ancak GitHub entegrasyonu
dosya yazma işlemlerinde 403 veriyor. Yazma izni açıldığında yeni dersleri doğrudan
depoya eklemek mümkün olacaktır.
