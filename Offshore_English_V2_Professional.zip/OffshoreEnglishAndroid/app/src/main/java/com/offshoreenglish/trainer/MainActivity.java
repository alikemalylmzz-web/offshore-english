package com.offshoreenglish.trainer;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView webView;

    private static final String MANIFEST_URL =
            "https://raw.githubusercontent.com/alikemalylmzz-web/offshore-english/main/lessons/manifest.json";

    private File lessonsDir;
    private File cachedManifestFile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        lessonsDir = new File(getFilesDir(), "downloaded_lessons");
        if (!lessonsDir.exists()) lessonsDir.mkdirs();
        cachedManifestFile = new File(getFilesDir(), "downloaded_lessons_manifest.json");

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(244, 247, 251));
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setTextZoom(100);
        settings.setMediaPlaybackRequiresUserGesture(true);

        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new AppBridge(), "AndroidBridge");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private String readText(File file) throws Exception {
        StringBuilder out = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                out.append(line).append('\n');
            }
        }
        return out.toString();
    }

    private void writeText(File file, String text) throws Exception {
        try (FileOutputStream output = new FileOutputStream(file)) {
            output.write(text.getBytes(StandardCharsets.UTF_8));
        }
    }

    private String downloadText(String urlString) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(urlString).openConnection();
        connection.setConnectTimeout(15000);
        connection.setReadTimeout(20000);
        connection.setUseCaches(false);
        connection.setRequestProperty("User-Agent", "Offshore-English-Android");
        connection.connect();

        int code = connection.getResponseCode();
        if (code < 200 || code >= 300) {
            throw new Exception("HTTP " + code);
        }

        StringBuilder out = new StringBuilder();
        try (InputStream input = new BufferedInputStream(connection.getInputStream());
             BufferedReader reader = new BufferedReader(
                     new InputStreamReader(input, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                out.append(line).append('\n');
            }
        } finally {
            connection.disconnect();
        }
        return out.toString();
    }

    private String safeId(String value) {
        if (value == null) return "";
        return value.replaceAll("[^a-zA-Z0-9_-]", "");
    }

    private JSONObject getCachedManifestObject() {
        try {
            if (cachedManifestFile.exists()) {
                return new JSONObject(readText(cachedManifestFile));
            }
        } catch (Exception ignored) {}
        try {
            JSONObject empty = new JSONObject();
            empty.put("version", 0);
            empty.put("lessons", new JSONArray());
            return empty;
        } catch (Exception ignored) {
            return new JSONObject();
        }
    }

    private void callbackUpdate(boolean ok, String message, JSONObject manifest) {
        final String js = "window.onLessonUpdateResult(" +
                (ok ? "true" : "false") + "," +
                JSONObject.quote(message) + "," +
                manifest.toString() + ");";
        runOnUiThread(() -> webView.evaluateJavascript(js, null));
    }

    private class AppBridge {
        @JavascriptInterface
        public String getCachedLessons() {
            return getCachedManifestObject().toString();
        }

        @JavascriptInterface
        public void checkForUpdates() {
            new Thread(() -> {
                try {
                    String manifestText = downloadText(
                            MANIFEST_URL + "?t=" + System.currentTimeMillis());
                    JSONObject remote = new JSONObject(manifestText);
                    JSONArray lessons = remote.optJSONArray("lessons");
                    if (lessons == null) lessons = new JSONArray();

                    JSONArray cachedLessons = new JSONArray();

                    for (int i = 0; i < lessons.length(); i++) {
                        JSONObject item = lessons.getJSONObject(i);
                        String id = safeId(item.optString("id", ""));
                        String url = item.optString("url", "");

                        if (id.isEmpty() || url.isEmpty()) continue;

                        String html = downloadText(url + (url.contains("?") ? "&" : "?")
                                + "t=" + System.currentTimeMillis());

                        File lessonFile = new File(lessonsDir, "lesson_" + id + ".html");
                        writeText(lessonFile, html);

                        JSONObject cached = new JSONObject(item.toString());
                        cached.put("local_file", lessonFile.getAbsolutePath());
                        cachedLessons.put(cached);
                    }

                    JSONObject cachedManifest = new JSONObject(remote.toString());
                    cachedManifest.put("lessons", cachedLessons);
                    writeText(cachedManifestFile, cachedManifest.toString());

                    callbackUpdate(true,
                            lessons.length() == 0
                                    ? "Henüz yeni ders yayınlanmadı."
                                    : "Yeni dersler kontrol edildi ve cihaza kaydedildi.",
                            cachedManifest);

                } catch (Exception e) {
                    callbackUpdate(false,
                            "Güncelleme kontrolü yapılamadı. İnternet bağlantısını kontrol et. (" +
                                    e.getMessage() + ")",
                            getCachedManifestObject());
                }
            }).start();
        }

        @JavascriptInterface
        public void openLesson(String lessonId) {
            try {
                String wanted = safeId(lessonId);
                JSONObject manifest = getCachedManifestObject();
                JSONArray lessons = manifest.optJSONArray("lessons");
                if (lessons == null) return;

                for (int i = 0; i < lessons.length(); i++) {
                    JSONObject item = lessons.getJSONObject(i);
                    if (wanted.equals(safeId(item.optString("id", "")))) {
                        String path = item.optString("local_file", "");
                        if (!path.isEmpty()) {
                            File f = new File(path);
                            if (f.exists()) {
                                runOnUiThread(() ->
                                        webView.loadUrl("file://" + f.getAbsolutePath()));
                            }
                        }
                        return;
                    }
                }
            } catch (Exception ignored) {}
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidBridge");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
