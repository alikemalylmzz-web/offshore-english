# Offshore English Professional v2.1

Professional Android UI + downloadable lesson system.

## Highlights
- New native-style dashboard
- Bottom navigation (Home / Lessons / Updates)
- Continue-learning shortcut
- Lesson search
- Professional offshore color system and icon
- Polished lesson cards/buttons/progress screens
- Android 12+ splash screen
- Downloadable future lessons via `lessons/manifest.json`
- Version code 3 / version name 2.1

Package: `com.offshoreenglish.trainer`

## Stable sideload updates
Debug APKs are signed with the bundled development keystore so future GitHub builds can install over Professional v2.1 without uninstalling. This development key is not intended for Google Play release signing.


## V2.2 Replit lesson feed
This build reads new lesson updates from:
https://gifted-weird-php--alikemalylmzz.replit.app/lessons/manifest.json

After this build is installed, future lesson HTML files can be published on Replit
and fetched from the app without rebuilding the APK for each lesson.


## Ocean Pro v2.3
- Redesigned professional offshore/maritime UI.
- Four-tab navigation: Home, Lessons, Progress, Updates.
- Lesson search and A1/A2 filters.
- Started-lesson progress tracking on-device.
- Replit lesson feed remains enabled for future lesson delivery.
- Stable debug signing configuration is preserved for app updates.
