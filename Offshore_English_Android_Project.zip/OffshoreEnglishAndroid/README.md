# Offshore English — Android uygulaması

Bu proje, Bölüm 1–4 İngilizce eğitim içeriklerini tek bir Android uygulamasında toplar.

## Özellikler
- Bölüm 1–4 tek ana menüde
- Çevrimdışı çalışma
- “Bilmiyorum → Öğret” modu
- Cümle kurma, çoktan seçmeli ve yanlış düzeltme alıştırmaları
- Offshore / gemi çalışma örnekleri
- İlerleme verisini cihazda saklama

## Android Studio ile APK
1. Bu klasörü Android Studio ile açın.
2. Gradle senkronizasyonunu bekleyin.
3. Build > Build App Bundle(s) / APK(s) > Build APK(s).
4. APK: `app/build/outputs/apk/debug/app-debug.apk`

## GitHub Actions ile APK
Projeyi GitHub'a yüklediğinizde `.github/workflows/build-apk.yml` otomatik APK derler.
Actions > Build Android APK > son çalıştırma > Artifacts > Offshore-English-APK.

Paket adı: `com.offshoreenglish.trainer`
Minimum Android: Android 6.0 (API 23)
